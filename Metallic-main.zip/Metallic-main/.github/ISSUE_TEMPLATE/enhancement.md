---
name: Enhancement
about: Request a new feature or enhancement
labels: enhancement
---
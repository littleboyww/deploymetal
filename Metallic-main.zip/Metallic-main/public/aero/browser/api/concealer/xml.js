// TODO: Determine if XML needs to be rewritten with XML linked documents, or if it is already handled in the mutation observer

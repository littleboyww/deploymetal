$aero.escape = str => new RegExp(`^(?:_+)?${str}$`, "g");

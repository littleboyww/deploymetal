// TODO: Parse permission policy

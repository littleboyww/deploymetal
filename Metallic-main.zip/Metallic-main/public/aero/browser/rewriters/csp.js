$aero.rewriteCsp = csp => ($aero.config.rewriteCSP ? csp : "");

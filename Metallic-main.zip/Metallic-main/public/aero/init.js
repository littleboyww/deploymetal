// Inits all the message handlers that power aero
import dynamicUpdates from "./this/handlers/updates.js";

dynamicUpdates();

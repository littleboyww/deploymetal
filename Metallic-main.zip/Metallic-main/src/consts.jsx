const obfuscation = true;
const github = "https://github.com/cognetwork-dev/Metallic";
const discord = "https://discord.com/invite/yk33HZSZkU";
const bareServerURL = new URL("/bare/", window.location);

export { obfuscation, github, discord, bareServerURL };
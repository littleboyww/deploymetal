import en from "./en/index.jsx"
import es from "./es/index.jsx"
import fr from "./fr/index.jsx"
import zh from "./zh/index.jsx"
import de from "./de/index.jsx"

var languages = {en, es, fr, zh, de}

export default languages;